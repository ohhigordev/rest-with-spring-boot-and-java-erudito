package br.com.ohhigordev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringBootAndJavaEruditoApplicationTests {

	@Test
	void contextLoads() {
	}

}
